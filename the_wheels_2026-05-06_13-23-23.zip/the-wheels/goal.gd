extends Area2D 

var level = 0; 

func _on_body_entered(body: Node2D) -> void:
	level += 1; 
