extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0

func _physics_process(delta: float) -> void:  
	#print($/root/Node2D/wheel.movement); 
	velocity = Vector2(5, 0);#$/root/Node2D/Wheel.movement;  
	#var col_info = move_and_collide(Vector2(5, 0) * delta);    
	#print(col_info);
	#if col_info:  
		#print("test");  
	#move_and_collide(Vector2(5, 0) * delta);    
	move_and_slide();   
